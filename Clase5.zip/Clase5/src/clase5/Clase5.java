package clase5;

public class Clase5 {

    public static void main(String[] args) {
        
        //Punto de entrada del proyecto
        
        System.out.println("Hola Mundo!");
        
        /*
            Interfaces Gráficas Java
        
            - AWT (Abstract Windows Type) Es la primer interface gráfica, viene dentro 
                del core de java, es la más veloz, no garantiza la misma apariencia en
                los distintos SO.
        
            - Swing: Garantiza la misma apariencia en todos los SO.
        
            - JavaFX: Cumple con el patron MVC, Cross Platform, Crea aplicaciones Desktop, Mobile y Web,
                        Esta discontinuada, fue sacada del Core de Java en la version 11.
        
        */
        
        
        //Llamar al formulario Hola.java
        //new Hola().setVisible(true);
        
        new Gestion().setVisible(true);
        
        
    }
    
}
