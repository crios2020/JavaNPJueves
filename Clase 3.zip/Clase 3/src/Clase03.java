import java.text.DecimalFormat;
import java.time.LocalDateTime;
import javax.swing.JOptionPane;

public class Clase03 {
	public static void main(String[] args) {
		//Uso de constantes: Las contanstes pertenecen a un tipo de datos primitivos (float, double, int, etc)
		// y solo pueden tener una asignación de valor en el momento de la declaración
		final double PI=3.14;
		//PI++;  //error
		
		//Estructura switch
		LocalDateTime ldt=LocalDateTime.now();
		int mes=ldt.getMonthValue();
		int diaSem=ldt.getDayOfWeek().getValue();
		
		System.out.println("Mes: "+mes);
		System.out.println("Dia: "+diaSem);
		//mes=25;
		switch(mes) {
			case 1: 	System.out.println("Enero"); 		break;
			case 2: 	System.out.println("Febrero"); 		break;
			case 3: 	System.out.println("Marzo"); 		break;
			case 4: 	System.out.println("Abril"); 		break;
			case 5: 	System.out.println("Mayo"); 		break;
			case 6: 	System.out.println("Junio"); 		break;
			case 7: 	System.out.println("Julio"); 		break;
			case 8: 	System.out.println("Agosto"); 		break;	
			case 9: 	System.out.println("Septiembre");	break; 	
			case 10: 	System.out.println("Octubre"); 		break;
			case 11: 	System.out.println("Noviembre"); 	break;
			case 12: 	System.out.println("Diciembre"); 	break;
			default: 	System.out.println("Error");
		}
		
		
		switch(mes) {
			case 1: case 2: case 12: 	System.out.println("Es Verano!");		break;
			case 3: case 4: case 5:		System.out.println("Es Otoño!");		break;
			case 6: case 7: case 8:		System.out.println("Es Invierno!"); 	break;
			case 9: case 10: case 11: 	System.out.println("Es Primavera!"); 	break;
			default: 	System.out.println("Error");
		}
		
		switch(diaSem) {
			case 1: 	System.out.println("Es Lunes"); 	break;
			case 2: 	System.out.println("Es Martes"); 	break;
			case 3: 	System.out.println("Es Miércoles"); break;
			case 4: 	System.out.println("Es Jueves"); 	break;
			case 5: 	System.out.println("Es Viernes"); 	break;
			case 6: 	System.out.println("Es Sábado"); 	break;
			case 7: 	System.out.println("Es Domingo"); 	break;
			default: 	System.out.println("Error");
		}
	
		switch(diaSem) {
			case 6: case 7:	System.out.println("Es Fin de Semana");		break;
			case 1: case 2: case 3: case 4: case 5: 
				System.out.println("Es Día Laboral");	break;
			default: 	System.out.println("Error");
		}
		
		//Estructuras de repetición!!
		
		//Estructura While
		int a=20;
		System.out.println("-- Inicio de Estructura While --");
		while (a<=10) {
			System.out.println(a);
			a++;
		}
		System.out.println("-- Fin de estructura While --");
		System.out.println(a);
		
		//Estructura do While
		a=20;
		System.out.println("-- Inicio de Estructura do While --");
		do {
			System.out.println(a);
			a++;
		} while(a<=10);
		System.out.println("-- Fin de Estructura do While --");
		System.out.println(a);
		
		//Uso de llaves
		
		//Modo microsoft
		a=1;
		while(a<=10) 
		{
			System.out.println(a);
			a++;
		}
		
		//Modo Abreviado
		a=1;
		while(a<=10) System.out.println(a++);
		
		
		//loop infinito
		//a=1;
		//while(true) {
		//	System.out.println(a);
		//	a++;
		//}
		
		//a=1;
		//while(a<=10 || true) {
		//	System.out.println(a);
		//	a++;
		//}
		
		//a=1;
		//while(a<=10 || a>=1) {
		//	System.out.println(a);
		//	a++;
		//}
		
		//a=1;
		//while(a<=10) {
		//	System.out.println(a--);
		//	a++;
		//}
		
		//a=1;
		//while(a<=10); 
		//{
		//	System.out.println(a);
		//	a++;
		//}
		
		a=1;
		System.out.println("-- Inicio de Estructura While --");
		while (a<=10) {
			System.out.println(a);
			a++;
		}
		System.out.println("-- Fin de estructura While --");
		System.out.println(a);
		
		//Estructura for
		System.out.println("-- Inicio de Estructura For --");
		for(int x=1; x<=10; x++) {
			System.out.println(x);
		}
		System.out.println("-- Fin de Estructura For --");
		//System.out.println(x);	//error x es varaible local
		
		//Uso de llaves
		//Modo abreviado
		for(int x=1; x<=10; x++) System.out.println(x);
		
		//Modo Microsoft
		for(int x=1; x<=10; x++) 
		{ 
			System.out.println(x);
		}
		
		//Recorridos con for usando variables locales
		for(a=1;a<=10;a++) {
			System.out.println(a);
		}
		System.out.println("-----------------------");
		System.out.println(a);
		System.out.println("-----------------------");
		for(a++;a<=20;a++) {
			System.out.println(a);
		}
		System.out.println("-----------------------");
		for(;a<=30;a++) {
			System.out.println(a);
		}
		System.out.println("-----------------------");
		for(;a<=40;) {
			System.out.println(a++);
		}
		System.out.println("-----------------------");
		for(;;) {
			//if(a==44) continue; loop infinito
			System.out.println(a++);
			if(a>=50) break;	//rompe el ciclo
		}
		System.out.println("-----------------------");
		for(;a<=60;a++) {
			if(a==55) continue;
			System.out.println(a);
			//if(a>=60) break;
		}
		
		//Recorrido con multiples variables de control
		for(int r=1, s=1; r<=5 && s<=10; r++, s++) {
			System.out.println(r+" "+s);
		}
		
		for(int r=1, s=1; r<=5 || s<=10; r++, s++) {
			System.out.println(r+" "+s);
		}
		
		//for anidado
		long cont=0;
		for(int x=1;x<=1000;x++) {
			for(int r=1;r<=1000;r++) {
				for(int s=1;s<=1000;s++) {
					cont++;
				}
			}
		}
		System.out.println(cont);
		
		//horas minutos segundos
		DecimalFormat df=new DecimalFormat("00");
		for(int hora=0;hora<24;hora++) {
			for(int minuto=0;minuto<60;minuto++) {
				for(int segundo=0;segundo<60;segundo++) {
					System.out.println(df.format(hora)+":"+df.format(minuto)+":"+df.format(segundo));
					//try {Thread.sleep(1000);} catch(Exception e) {}
				}
			}
		}
		
		//loop infinitos
		//for(int x=1;true;x++) System.out.println(x);
		//for(int x=1;;x++) System.out.println(x);
		//for(int x=1;x<=10;) System.out.println(x);
		//for(int x=1;x<=10 || true;x++) System.out.println(x);
		//for(int x=1;x<=10 || x>=1;x++) System.out.println(x);
		
		a=4;
		//for(int x=a;a<=10;x++) System.out.println(x);
		//for(int x=a; x<=10; a++) System.out.println(x);
		//error
		//for(int x=1;x<=10;x++); System.out.println(x);
		
		
		JOptionPane.showMessageDialog(null, "Hola a todos");
		
	}
}
