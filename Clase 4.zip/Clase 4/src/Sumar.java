public class Sumar{
	public static void main(String[] args){
		if(args.length!=2){
			System.out.println("Se deben enviar 2 enteros");
		}else{
			int nro1=Integer.parseInt(args[0]);
			int nro2=Integer.parseInt(args[1]);
			int resultado=nro1+nro2;
			System.out.println("Total: "+resultado);
		}
	}
}
