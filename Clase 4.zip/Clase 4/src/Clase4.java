import java.util.Arrays;

public class Clase4 {
    public static void main(String[] args) {
        System.out.println("Hola Mundo!");

        // Vectores - Arrays

        // declarar vectores longitud 4 (grado 4)
        int[] numeros = new int[4]; // valido
        // int numeros[]=new int[4]; //valido
        String[] nombres = new String[4];

        // cargar valores en los vector
        numeros[0] = 1;
        nombres[0] = "Juan";
        numeros[1] = 2;
        nombres[1] = "Maria";
        numeros[2] = 3;
        nombres[2] = "Jose";
        numeros[3] = 4;
        nombres[3] = "Ana";

        // La primer posición de un vector tiene indice 0
        // La ultima posición de un vector tiene indice N-1

        // Error fuera de Rango
        // numeros[4]=5;
        // nombres[4]="Mirta";

        // Error fuera de Rango
        // numeros[-2]=5;
        // nombres[-2]="Karina";

        // Sobrescribo y reemplazo a Jose por Javier
        nombres[2] = "Javier";

        /*
         * numeros nombres indices 1 Juan 0 2 Maria 1 3 Jose/Javier 2 4 Ana 3
         * 
         */

        // Imprimir la posición indice 2
        System.out.println(numeros[2] + " " + nombres[2]);

        // Recorrer el vector
        System.out.println("*************************************************");
        for (int a = 0; a < 4; a++) {
            System.out.println(numeros[a] + " " + nombres[a]);
        }

        // Método length
        System.out.println("Longitud Vector numeros: " + numeros.length);

        for (int a = 0; a < numeros.length; a++) {
            System.out.println(numeros[a] + " " + nombres[a]);
        }

        System.out.println("*************************************************");
        // Recorrido usando while
        int x = 0;
        while (x < numeros.length) {
            System.out.println(numeros[x] + " " + nombres[x]);
            x++;
        }

        System.out.println("*************************************************");
        // Recorrido inverso
        for (int a = numeros.length - 1; a >= 0; a--) {
            System.out.println(numeros[a] + " " + nombres[a]);
        }

        System.out.println("*************************************************");
        // vector args: contiene argumentos que ingresan por consola
        System.out.println("Longitud Vector args: " + args.length);
        for (int a = 0; a < args.length; a++) {
            System.out.println(args[a]);
        }

        // Declaración abreviada
        int[] vector = { 26, 23, 38, 39, 29, 10, 12, 32, 38, 35, 5, 12, 8, 17, 12 };
        System.out.println("Longitud vector: " + vector.length);
        for (int a = 0; a < vector.length; a++) System.out.print(vector[a] + ", ");
        System.out.println();
        
        //Totalizar y promediar un vector numerico
        int suma=0;
        for(int a=0;a<vector.length; a++){
            suma+=vector[a];
        }
        System.out.println("total: "+suma);
        System.out.println("promedio:"+((float)suma/vector.length));

        //Busqueda de Máximos y Mínimos
        //int[] vector = { 26, 23, 38, 39, 29, 10, 12, 32, 38, 35, 5, 12, 8, 17, 12 };
        int min=vector[0], max=vector[0];
        for (int a = 0; a <vector.length; a++){
            if(vector[a]<min) min=vector[a];
            if(vector[a]>max) max=vector[a];
        }
        System.out.println("Valor Mínimo: "+min);
        System.out.println("Valor Máximo: "+max);

        //operador Resto %
        System.out.println(15%2);           //  1
        System.out.println(14%2);           //  0
        System.out.println(-14%2);          //  0
        System.out.println(-15%2);          // -1


        //Contar cantidad de numeros pares
        //Contar cantidad de numeros impares
        //Contar cantidad de numeros 12
        int contPares=0, contImpares=0, cont12=0;
        for (int a = 0; a <vector.length; a++){
            if(vector[a]%2==0)  contPares++;
            else                contImpares++;
            if(vector[a]==12)   cont12++;
        }
        System.out.println("Cantidad pares: "+contPares);
        System.out.println("Cantidad Impares: "+contImpares);
        System.out.println("El número 12 se repite "+cont12+" veces.");

        int[] pares={2,4,6,8,10};
        int[] impares=new int[pares.length];
        int[] pares2=new int[pares.length];

        /*
                pares       impares     impares
                2           ___         ___
                4           ___         ___
                6           ___         ___
                8           ___         ___
                10          ___         ___
        */

        //Copiar vector pares a impares
        for(int a=0;a<pares.length; a++){
            impares[a]=pares[a]-1;
        }

        for(int a=0;a<pares.length; a++){
            System.out.println(impares[a]+" "+pares[a]);
        }

        //Copiar de pares a pares2
        System.arraycopy(pares, 0, pares2, 0, pares.length);

        for(int a=0;a<pares.length; a++){
            System.out.println(pares[a]+" "+pares2[a]);
        }

        System.out.println("vector");
        for (int a = 0; a < vector.length; a++) System.out.print(vector[a] + ", ");
        System.out.println();

        //Ordena un vector
        Arrays.sort(vector);

        System.out.println("vector");
        for (int a = 0; a < vector.length; a++) System.out.print(vector[a] + ", ");
        System.out.println();

        //Recorrido reverso
        for (int a = vector.length-1; a >=0; a--) System.out.print(vector[a] + ", ");
        System.out.println();

    }
}
