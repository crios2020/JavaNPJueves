import java.util.Scanner;
import java.util.Vector;

public class Login {
    public static void main(String[] args) {

        String[] usuarios = {"Juan", "Maria", "Jose", "Ana"};
        String[] claves   = {"123" , "321"  , "abc" , "111"};

        System.out.println("\033[32m");
		System.out.println("**********************************************");
		System.out.println("*     G E S T I Ó N  D E  U S U A R I O S    *");
		System.out.println("**********************************************");
		System.out.println("\033[34m");
		System.out.print("Ingrese su nombre de Usuario: ");
		String user=new Scanner(System.in).next();
		System.out.println();
		System.out.print("Ingrese su Clave: ");
		String pass=new Scanner(System.in).next();
		System.out.println("\u001B[0m");

        //System.out.println("User: "+user+", pass: "+pass);

        boolean existe=false;
        int donde=0;

        for(int a=0;a<usuarios.length;a++){
            if(user.equals(usuarios[a])){                           //case sensitive
            //if(user.equalsIgnoreCase(usuarios[a])){               //case insensitve
                existe=true;
                donde=a;
            }
        }

        //System.out.println(existe+" "+donde);

        if(existe){
            if(pass.equals(claves[donde])){
                System.out.println("\033[32mBienvenidos al Sistema!\u001B[0m");
                System.out.println("\033[32mHola "+user+"!\u001B[0m");
            }else{
                System.out.println("\033[31mClave Incorrecta!\u001B[0m");
            }
        }else{
            System.out.println("\033[31mUsuario Incorrecto!\u001B[0m");
        }

    }
}
